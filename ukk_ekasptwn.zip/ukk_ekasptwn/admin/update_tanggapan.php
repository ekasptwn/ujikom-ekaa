<?php
require '../koneksi.php';
$id_tanggapan = $_POST['id_tanggapan'];
$id_pengaduan= $_POST['id_pengaduan'];
$tgl = $_POST['tgl_tanggapan'];
$tanggapan = $_POST['tanggapan'];
$id = $_POST['id_petugas'];

$sql=mysqli_query($koneksi, "UPDATE tanggapan SET tanggapan='$tanggapan', id_pengaduan='$id_pengaduan', tgl_tanggapan='$tgl', id_petugas='$id' WHERE id_tanggapan='$id_tanggapan' ");

if($sql){
    ?>
        <script type="text/javascript">
            alert ('Data Disimpan');
            window.location='admin.php?url=lihat_tanggapan';
        </script>
    <?php
}
?>