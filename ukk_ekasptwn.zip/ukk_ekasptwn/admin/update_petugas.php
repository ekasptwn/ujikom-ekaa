<?php
require '../koneksi.php';
$nama = $_POST['nama_petugas'];
$user = $_POST['username'];
$pass = $_POST['password'];
$telp = $_POST['telp'];
$level = $_POST['level'];

$sql = mysqli_query($koneksi, "UPDATE petugas SET nama_petugas='$nama', username='$user', password='$pass', telp='$telp', level='$level' WHERE ")
if($sql){
    ?>
        <script type="text/javascript">
            alert ('Data Disimpan');
            window.location='admin.php?url=lihat_petugas';
        </script>
    <?php
}
?>